package ru.mirea.ikbo1319.pr12.classes;

public class FileTest {
    public static void main(String args[]){
        FilesReader fileReader = new FilesReader("C:\\Users\\Nastya\\IdeaProjects\\smth-on-java-pr12\\src\\main\\" +
                "java\\ru\\mirea\\ikbo1319\\pr12\\file\\firstFile",
                "C:\\Users\\Nastya\\IdeaProjects\\smth-on-java-pr12\\src\\main\\java\\ru\\mirea\\ikbo1319\\pr12\\" +
                        "file\\secondFile");
        fileReader.FileRead();
        fileReader.FileDel();
    }
}
