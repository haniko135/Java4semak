package ru.mirea.ikbo1319.pr12.classes;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

public class FilesReader {
    private static File file1;
    private static File file2;

    public FilesReader(String path1, String path2) {
        file1 = new File(path1);
        file2 = new File(path2);
    }

    @PostConstruct
    public static void FileRead(){
        StringBuilder str = new StringBuilder();
        try {
            Scanner scanner = new Scanner(file1);
            while(scanner.hasNext()){
                str.append(scanner.nextLine());
            }
            if(file2.createNewFile()){
                FileWriter fileWriter = new FileWriter(file2);
                fileWriter.write(String.valueOf(str.hashCode()));
                fileWriter.close();
            }
        } catch (Exception e){
            try{
                if(file2.createNewFile()){
                    FileWriter fileWriter = new FileWriter(file2);
                    fileWriter.write("null");
                    fileWriter.close();
                }
            } catch (Exception j){
                System.out.println(j);
            }
        }
    }

    @PreDestroy
    public static void FileDel(){
        try{
            System.gc(); //очистка мусора
            Files.delete(Paths.get(file1.getPath()));
        }catch(Exception k){
            System.out.println(k);
        }
    }
}
