package ru.mirea.ikbo1319.pr11.smthonjavapr11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmthOnJavaPr11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
