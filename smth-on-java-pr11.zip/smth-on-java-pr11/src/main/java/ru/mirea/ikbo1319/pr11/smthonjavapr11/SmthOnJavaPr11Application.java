package ru.mirea.ikbo1319.pr11.smthonjavapr11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmthOnJavaPr11Application {

	public static void main(String[] args) {
		SpringApplication.run(SmthOnJavaPr11Application.class, args);
	}

}
