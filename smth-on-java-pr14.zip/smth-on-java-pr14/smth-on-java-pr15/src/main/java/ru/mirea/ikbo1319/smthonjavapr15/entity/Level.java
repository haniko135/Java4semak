package ru.mirea.ikbo1319.smthonjavapr15.entity;

import javax.persistence.*;

@Entity
@Table(name = "level")
public class Level {
    private String nameLevel;
    private String complexity;
    private Long id;

    public Level() {
    }

    public String getNameLevel() {
        return nameLevel;
    }

    public void setNameLevel(String nameLevel) {
        this.nameLevel = nameLevel;
    }

    public String getComplexity() {
        return complexity;
    }

    public void setComplexity(String complexity) {
        this.complexity = complexity;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getId() {
        return id;
    }
}
