package ru.mirea.ikbo1319.smthonjavapr15.dao;

import org.springframework.stereotype.Repository;
import ru.mirea.ikbo1319.smthonjavapr15.entity.Level;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import java.util.List;

@Repository
@Transactional
public class LevelDao {

    @PersistenceContext
    private EntityManager entityManager;

    public Level createLevel(Level level){
        entityManager.persist(level);
        return level;
    }

    public void deleteLevel(int id){
        Level level = entityManager.find(Level.class, id);
        if(level != null){
            entityManager.remove(level);
        }
    }

    public List<Level> getAll(){
        return entityManager.createQuery("from Level l order by l.id desc", Level.class).getResultList();
    }

    public Level getById(int id){
        return entityManager.find(Level.class, id);
    }
}
