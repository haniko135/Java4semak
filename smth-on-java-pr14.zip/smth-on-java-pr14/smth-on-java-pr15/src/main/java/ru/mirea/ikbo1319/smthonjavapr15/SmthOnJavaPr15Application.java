package ru.mirea.ikbo1319.smthonjavapr15;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmthOnJavaPr15Application {

    public static void main(String[] args) {
        SpringApplication.run(SmthOnJavaPr15Application.class, args);
    }

}
