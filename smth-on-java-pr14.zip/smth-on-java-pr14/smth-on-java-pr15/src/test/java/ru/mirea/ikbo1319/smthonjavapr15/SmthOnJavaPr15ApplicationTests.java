package ru.mirea.ikbo1319.smthonjavapr15;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmthOnJavaPr15ApplicationTests {

    @Test
    void contextLoads() {
    }

}
