package ru.mirea.ikbo1319.smthonjavapr16;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmthOnJavaPr16Application {

    public static void main(String[] args) {
        SpringApplication.run(SmthOnJavaPr16Application.class, args);
    }

}
