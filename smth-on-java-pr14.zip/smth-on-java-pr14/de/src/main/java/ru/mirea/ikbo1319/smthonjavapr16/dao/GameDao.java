package ru.mirea.ikbo1319.smthonjavapr16.dao;

import org.springframework.stereotype.Repository;
import ru.mirea.ikbo1319.smthonjavapr16.entity.Game;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
public class GameDao {
    @PersistenceContext
    private EntityManager entityManager;

    public Game createGame(Game game){
        entityManager.persist(game);
        return game;
    }

    public void deleteGame(Long id){
        Game game = entityManager.find(Game.class, id);
        if(game != null){
            entityManager.remove(game);
        }
    }

    public List<Game> getAll() {
        return entityManager.createQuery(
                "from game g order by g.id desc", Game.class)
                .getResultList();
    }

    public Game getById(Long id) {
        return entityManager.find(Game.class, id);
    }

}
