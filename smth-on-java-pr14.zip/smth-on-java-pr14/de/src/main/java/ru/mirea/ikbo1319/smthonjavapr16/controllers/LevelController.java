package ru.mirea.ikbo1319.smthonjavapr16.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import ru.mirea.ikbo1319.smthonjavapr16.dao.LevelDao;
import ru.mirea.ikbo1319.smthonjavapr16.entity.Level;

import java.util.List;

@Controller
@RequestMapping(value="/api", produces = MediaType.APPLICATION_JSON_VALUE)
public class LevelController {

    @Autowired
    private LevelDao levelDao;

    @GetMapping("/setLevel")
    public Level setLevel(@RequestBody Level level){
        return levelDao.createLevel(level);
    }

    @GetMapping("/getLevels/{id}")
    public Level getLevelById(@PathVariable Long id){
        return levelDao.getById(id);
    }

    @GetMapping("/getLevels")
    public List<Level> getLevels(){
        return levelDao.getAll();
    }

    @GetMapping("/deleteLevels/{id}")
    public void deleteLevel(@PathVariable Long id){
        levelDao.deleteLevel(id);
    }
}
