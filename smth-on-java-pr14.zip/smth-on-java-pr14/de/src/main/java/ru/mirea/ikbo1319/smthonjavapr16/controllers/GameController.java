package ru.mirea.ikbo1319.smthonjavapr16.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import ru.mirea.ikbo1319.smthonjavapr16.dao.GameDao;
import ru.mirea.ikbo1319.smthonjavapr16.entity.Game;

import java.util.List;

@Controller
@RequestMapping(value="/api", produces = MediaType.APPLICATION_JSON_VALUE)
public class GameController {

    @Autowired
    private GameDao gameDao;

    @GetMapping("/setGame")
    public Game setGame(@RequestBody Game game){
        return gameDao.createGame(game);
    }

    @GetMapping("/getGames/{id}")
    public Game getGameById(@PathVariable Long id){
        return gameDao.getById(id);
    }

    @GetMapping("/getGames")
    public List<Game> getGames(){
        return gameDao.getAll();
    }

    @GetMapping("/deleteGames/{id}")
    public void deleteGame(@PathVariable Long id){
        gameDao.deleteGame(id);
    }
}
