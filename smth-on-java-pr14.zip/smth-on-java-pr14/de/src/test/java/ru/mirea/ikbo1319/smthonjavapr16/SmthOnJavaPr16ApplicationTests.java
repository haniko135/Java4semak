package ru.mirea.ikbo1319.smthonjavapr16;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmthOnJavaPr16ApplicationTests {

    @Test
    void contextLoads() {
    }

}
